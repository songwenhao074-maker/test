# PreGANPlus / FT-MoE 项目上下文（2026-08-23 精简版）

> 当前主线：**QoS 过载标签**（模拟器派生真实故障 ground truth）。历史主线
> （v8 留出协议、rulefeat、v11-v17 数据迭代）已全部废弃，细节见
> `notes_v9_experiment.md`（历史笔记）与 `PROJECT_CONTEXT_full.md`（历史摘要）。

## 一、项目与论文

- **论文**：FT-MoE（AAAI 2026 匿名投稿），双路径故障检测模型（MoE + 调度感知图注意力 + MHA 融合）
- **目标**：消融链 v0 < v1b < v2c2 < v3b2 < v4c1（每个新模块有提升），复现论文指标
  （FT-MoE 参考：F1 .8766 / HR .6496 / NDCG .6021）
- **环境**：Windows 11 CPU-only，torch 2.13.0+cpu，dgl 1.1.2，16 核，内存 ~16GB
- **代码**：模型 `recovery/PreGANSrc/src/models_v2.py`（v0-v4c1 继承链 + 零门残差）；
  训练 `train_progressive_v2.py`；评估 `eval_holdout.py`；数据构造与调度见第四节

## 二、最终协议与结果（2026-08-23 定稿）

**协议**：multiseed 606 行（3 种子 gobi 重放拼接，train 404 = s42+s1 / test 202 = s6，
自然碰撞对 130 对）；Q=2（V2_PROTO_DIM=2）；**tol1 标签**（过载 ±1 步时间扩展）；
85ep；12 experts；gd0；种子 {1,2,6}；留出 TRAIN_ROWS=404。

**标签体系**（`data/qos_overload_ms_tol1/`）：
- **检测**：物理主机过载 binary（GOBI 重放派生：sum base_ips > cap；tol1 = ±1 步扩展）
- **分类**：检测正样本上的需求画像类 1=cpu / 2=ram / 3=disk（cpu 主列>p98→1；
  ram>p98/1.5→2；disk>p98/1.5→3；fallback demand/cap argmax；test 分布 63/28/9）
- ram/disk 类是**阈值注入**的画像类（模拟器里 ram/disk 物理上不是瓶颈；用户授权
  "构造数据集灵活、性能为主、cpu 综合真实"）；输入数据不放大（归一化会抵消）

**最终结果**（3 种子均值，argmax 口径，ckpt `checkpoints_qos_overload_ms_tol1/` 15 个 snap85）：

| 变体 | 检测 F1 | 分类 HR@100 |
|---|---|---|
| v0 | .4287 | .3781 |
| v1b | .4117 | .3495 |
| v2c2 | .4122 | .4221 |
| v3b2 | **.6855** | .5959 |
| v4c1 | .6792 | **.5986** |

- 分类链后段单调且接近论文（.596/.599 ≈ .6496）；检测链 v3b2 大跳 +.27（图路径
  schedule 机制增益，recall .93）；**前段 v0/v1b/v2c2 等价**（架构事实）
- **严格单调链未达成**：v1b < v0（两指标）、v4c1 < v3b2（仅检测 Δ.006）；形态 =
  "前段等价 + 后段机制增益"（弱链）
- 检测绝对值 .68 低于论文 .8766：真实过载（打包型故障依赖调度）比故障注入数据难，
  碰撞对协议下无 schedule 模型信息受限（oracle：trace-only f1≈0，+schedule .949）

## 三、关键机制与坑（新对话必读）

1. **FREEZE 强监督**（v3b2/v4c1 必需）：GRAPH_AUX=1.0 + GRAPH_AUX_MARGIN_POS=1.0
   + NEG=2.0 + V2_GRAPH_LR=0.01 + V2_GRAPH_EXPLICIT=1 + V2_GRAPH_SCALE=3 +
   FREEZE_AFTER=30 + FREEZE_KEEP='graph,attn,mha'——冻结基座逼图路径吸收碰撞对误差
2. **RULE_AUX 需 GRAPH_AUX>0 才生效**（aux_fn 挂载条件）；RULE_AUX 本身在 tol1 下未用
3. **在线协议**：ONLINE_TUNE=0（过载链在线微调有反馈回路缺陷：迁移消除过载→微调标签
   全 0→模型失忆）；在线标签 ONLINE_LABEL_MODE=overload（从 hostinfo baseips>cap 取）
4. **eval 与训练 env 必须一致**：V2_PROTO_DIM=2、V2_GRAPH_EXPLICIT=1、V2_GRAPH_SCALE=3
   （v3b2/v4c1 训练用了 EXPLICIT/SCALE，eval 不设会 load_state_dict 失败）
5. **eval_holdout 归一化用全量 max**（与训练 train-only max 不一致）→ 数字有两口径，
   报告以 eval_holdout 口径为准（diag_overload_preds.py 是 train-only-max 口径）
6. **容差评估（不改标签）无效**：FP 也按容差膨胀净抵消；必须扩展训练标签（build_tol_labels）
7. **磁盘满**：训练被杀（rc=120）或 ckpt 损坏（torch.save 半写，load 报
   PytorchStreamReader）——训练前查 F 盘空间；F 盘曾满，已清理 ~65GB（v8 最终 ckpt
   备份在 D:\pregan_backup\）
8. **3 并行 v4c1（最大模型）偶发 OOM**（DefaultCPUAllocator）→ 补训用单进程；
   OMP_NUM_THREADS=3 固定（可复现）
9. 训练 job 勿用 job_output wait（触发进程树清理）——只轮询日志；调度器
   （run_chain_overload.py）3 并行，CHAIN_VARIANTS env 过滤变体

## 四、数据/脚本/ckpt 清单（保留）

- **数据**：`recovery/PreGANSrc/data/qos_overload_ms_tol1/`（最终：time_series 606×112、
  schedule_series 606×16×16、labels_overload.npy、labels_overload_class.npy）；
  源数据 `qos_overload_rs35_s{42,1,6}/`（3 种子重放）→ `qos_overload_multiseed/`（拼接）
- **构造脚本**（可重生成全链）：`dump_replay.py`（种子重放+过载标签，RAM_SCALE env）、
  `build_multiseed.py`（3 种子拼接）、`build_class_labels.py`（画像类+阈值注入）、
  `build_tol_labels.py`（±1 步扩展）
- **训练/评估**：`train_progressive_v2.py`（LABEL_MODE=overload）、
  `run_chain_overload.py`（15 runs 调度器）、`eval_holdout.py`（F1+HR@100）、
  `diag_overload_preds.py`（协议口径诊断）、`tau_sweep_chain.py`、`tol_eval.py`
- **在线 QoS**：`probe_model.py`（单探针）、`run_qos_probe_chain.py`（15 探针调度）；
  在线代码改动：`recovery/PreGANSrc/src/utils.py`（ONLINE_LABEL_MODE=overload 分支）、
  `recovery/FTMoEChain.py`（ONLINE_TUNE=0）、`simulator/workload/OfflineTraceWorkloadV2.py`
  （RAM_SCALE env）
- **ckpt**：`checkpoints_qos_overload_ms_tol1/`（15 个 `*_snap85.ckpt`，Q=2）
- **文档**：`notes_v9_experiment.md`（完整实验笔记，含最终结果节）、
  `PROJECT_CONTEXT_full.md`（v8 时代历史摘要）
- **模拟器事实**（调查结论）：真实故障 = GOBI 打包导致的物理主机 CPU 过载（主机 6/14
  热点）；p98 标签与真实过载 host 级错位（prec .21/rec .09）→ 已弃用；SLA 计数有 bug
  （Stats.py `len(np.where())` 恒 1）

## 五、可选后续（未做）

- QoS 全链在线验证（run_qos_probe_chain.py，ONLINE_TUNE=0）
- 种子搜索/ensemble/best-epoch 提升检测 F1（见笔记"最终结果"节）
- 论文消融表撰写（当前形态：图路径消融有损成立，MoE/MHA 增量在噪声带）
