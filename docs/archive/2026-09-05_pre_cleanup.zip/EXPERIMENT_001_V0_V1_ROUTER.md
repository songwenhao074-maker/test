# Experiment 001 — Stage-A v0 versus ordinary-router v1

Date: 2026-09-04  
Status: completed pilot; not a formal validation or test result.

## Goal and scope lock

This one atomic Stage-A experiment checks whether adding the execution-plan
v1 module — eight `64 -> 128 -> 64` GELU experts and an ordinary learned
`Linear(64, 8) -> softmax` router, with all experts weighted for every
host — can produce a measurable validation benefit over v0.  It ran only
`v0` and `v1`, only seed `1`, and no QoS, v2/v3/v4, test evaluation,
hyperparameter search, or test-set inspection was performed.

## Isolated implementation changes

- Added `recovery/PreGANSrc/src/ftmoe_ablation.py`: the common float32,
  batch-first `[B,16,12,7]` two-layer/four-head time encoder; v0; and v1's
  eight-expert softmax MoE.  The v0/v1 forward method accepts no schedule
  argument, so these variants cannot use the generated schedule array.
- Added `build_ftmoe_ablation_screening_data.py`: a reproducible temporary
  Stage-A data generator.
- Added `train_ftmoe_ablation_screening.py`: batch=32 AdamW training,
  warmup (five epochs), cosine decay to `1e-5`, gradient clipping 1.0,
  validation-only best-model selection, patience 8, checkpoint resume, and
  epoch resource checks.  It opens only train/validation episode indices.
- No existing legacy model, data, checkpoint, or execution-plan file was
  edited.  The only retained model artifacts are each run's `best.pt` and
  `final.pt` in `artifacts/ftmoe_ablation/screening_001/`.

## Data and split

Source: `build_ftmoe_ablation_screening_data.py --seed 101` generated a
**temporary simulator-inspired screening corpus** of 50 independent episodes
by 40 intervals = 2,000 intervals.  It contains seven resource features for
each of 16 hosts, 12-step left-padded history windows, and labels determined
only by a next-interval CPU/RAM/Disk capacity violation (`1/2/3`), not by a
migration edge or injected event flag.  Workload mechanisms are distributed
over episodes as 20 time-trend, 10 heterogeneous-mode, 8 regime-shift,
8 schedule-overload, and 4 cross-path episodes.

- Train: episodes 0--34, 1,400 intervals, positive host-step rate 27.62%.
- Validation: episodes 35--39, 200 intervals, positive host-step rate 29.19%.
- Test (unused): episodes 40--49, 400 intervals, positive host-step rate
  27.66%.  No pilot code opens its indices.

The data manifest is
`artifacts/ftmoe_ablation/screening_001/data/manifest.json`.  This deliberately
does **not** replace the planned 10,000-interval, shadow-simulator-derived
corpus; the result therefore cannot support the plan's final claims.

## Fixed configuration and resource controls

- Models: v0 temporal baseline; v1 differs only by the specified ordinary
  softmax MoE.  The common v0/v1 encoder, heads, and prototypes are constructed
  before v1's optional branch, giving common parameters identical seed-1
  initialization.
- Seed=1; maximum 25 epochs; batch size=32; AdamW `lr=3e-4`,
  `weight_decay=1e-4`; five-epoch linear warmup; cosine minimum `1e-5`;
  float32; `num_workers=0`; no `torch.compile`; gradient clip 1.0.
- Loss: `0.55 L_det + 0.35 L_cls + 0.10 L_proto + 0.01 L_balance`.
  The v1 balance term is the mean-router-probability deviation from uniform.
- One training process at a time; `OMP/MKL/OPENBLAS_NUM_THREADS=4`,
  PyTorch intra-op=4 and inter-op=1; Windows process priority BelowNormal.
  The runner refuses to start an epoch below 5 GiB available RAM or 20 GiB
  free disk.

Because available system RAM briefly fell below 5 GiB after early v1 epochs,
the resource guard safely ended those invocations.  The same v1 checkpoint was
then resumed only after memory recovered; no threshold was reduced.  All 25
epochs ultimately completed.  This illustrates why the resume state is part
of the new runner.

## Commands actually used

```powershell
& 'D:\Anaconda\envs\dynmoe\python.exe' -m py_compile `
  recovery\PreGANSrc\src\ftmoe_ablation.py `
  build_ftmoe_ablation_screening_data.py train_ftmoe_ablation_screening.py
& 'D:\Anaconda\envs\dynmoe\python.exe' build_ftmoe_ablation_screening_data.py `
  --output artifacts\ftmoe_ablation\screening_001\data --seed 101
$env:OMP_NUM_THREADS='4'; $env:MKL_NUM_THREADS='4'; $env:OPENBLAS_NUM_THREADS='4'
& 'D:\Anaconda\envs\dynmoe\python.exe' -u train_ftmoe_ablation_screening.py v0 `
  --seed 1 --data artifacts\ftmoe_ablation\screening_001\data `
  --output artifacts\ftmoe_ablation\screening_001 --epochs 25
& 'D:\Anaconda\envs\dynmoe\python.exe' -u train_ftmoe_ablation_screening.py v1 `
  --seed 1 --data artifacts\ftmoe_ablation\screening_001\data `
  --output artifacts\ftmoe_ablation\screening_001 --epochs 25
# v1 used the identical final command with --resume after safe guard stops.
```

## Results (validation selected only)

`F1` is the positive-class detection F1.  `HR@100` and `NDCG@100` rank the
top 100 host-step diagnostic candidates by `P(anomaly) * max(P(resource))`;
a relevant item is an anomalous host whose predicted resource class is correct.

| Variant | Best validation epoch | Train F1 at final | Validation F1 | HR@100 | NDCG@100 |
|---|---:|---:|---:|---:|---:|
| v0 | 20 | 0.7857 | 0.7957 | 0.9900 | 0.99255 |
| v1 ordinary softmax router | 23 | 0.7850 | 0.7972 | 0.9900 | 0.99255 |

Best v1 validation precision/recall were 0.7590/0.8394; v0 were
0.7679/0.8255.  Per-epoch measurements are in each run's `epochs.csv`; full
selected metrics are in `summary.json`.

Elapsed training time was 75.17 s for v0.  v1 consumed about 87.21 s across
the guard-safe resumed invocations (the final uninterrupted segment was
49.20 s).  Recorded peak process RSS at epoch starts was 0.306 GiB (v0) and
0.324 GiB (v1); minimum available RAM at admitted epoch starts was 5.059 GiB
and 5.003 GiB, respectively.  Free disk stayed above 124.98 GiB.

## Decision

**No, v1 does not yet satisfy the execution plan's `v1 > v0` acceptance
criterion.**  Its seed-1 validation F1 is directionally higher by only
0.00149, below the required 0.005 meaningful adjacent gain.  HR@100 is tied,
and NDCG@100 is numerically tied between v0 and v1.  One seed is also
insufficient for the plan's direction-consistency condition.  This run does
verify that the ordinary all-expert softmax router, losses, checkpointing,
resource guard, and validation-only comparison are trainable end-to-end.

## Issues found and one next experiment only

1. The screening corpus is mechanism-covered but not the required
   shadow-simulator corpus, so it is suitable only for Stage-A plumbing and
   directional screening.
2. The strict 5 GiB RAM start guard can cause safe interruption on this host;
   checkpoint resume preserved model/optimizer/scheduler/RNG state for the
   completed continuation.  The first interrupted pre-resume v0 checkpoint
   predated DataLoader-generator persistence, but v0 was already complete;
   all subsequent v1 resumes saved it.
3. A single seed has no evidential power to distinguish the 0.00149 F1 gap
   from noise.

The **only recommended next experiment** is the same frozen Stage-A v0/v1
ordinary-router comparison at seed=2, with the same 2,000-interval manifest,
25-epoch cap, validation-only selection, and resource guard.  Do not alter
the data, model, or hyperparameters before that paired seed is obtained.
