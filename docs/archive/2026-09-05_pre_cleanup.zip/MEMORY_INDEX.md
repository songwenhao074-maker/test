# Memory Index

- [v9 提分与链重构交接（2026-08-20 最新）](ftmoe-v9-boost-status.md) — **新对话必读**：用户严格单调链约束、高分方案已达成（.75/.86）、v11-v17 数据重构失败、待决策三方向
- [留出协议定稿 v8（当前主线）](heldout-chain-v8-final.md) — **必须先读**：v8 四周期留出协议、GRAPH_AUX/V2_GRAPH_LR 机制、后段链结果（v4c1 双最优）、**⚠️ 资源纪律（并行 ≤3 进程，5 进程 OOM）**、已被取代的旧结论清单
- [故障分类口径](fault-classification-experiment.md) — 类标签构造坑（make_labels_p98 vs form_test_dataset）、论文 HitRate@100%/NDCG@100% 定义（单类标签下 HR≡NDCG≡top-1 命中）、LR 探针结论
- [QoS 重放根因 bug 修复](qos-replay-root-cause-bugs.md) — 两个通用 bug 修复方法（窗口 pad、决策用错调度），适用于任何检测模型
- [QoS 链 v2 实验](qos-chain-v2-experiment.md) — GAN_FRESH 前缀 bug、GAN 在线正反馈机制（触发量→训练量→QoS 假象）；数值为旧模型口径
