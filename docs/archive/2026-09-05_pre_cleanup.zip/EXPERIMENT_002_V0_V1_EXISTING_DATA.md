# Experiment 002 — Existing-data v0/v1 ablation segment

Date: 2026-09-04  
Status: validation segment accepted; locked replay test block not evaluated.

## Goal

Verify the first ablation segment using the repository's existing
`qos_overload_ms_tol1` dataset.  The acceptance rule follows the user's
clarification: compare the mean over seeds; individual seeds do not need to
improve.

## Data protocol

- Existing source only: `recovery/PreGANSrc/data/qos_overload_ms_tol1`.
- Shape: 606 intervals, 16 hosts, 7 features per host.
- Replay blocks 42 and 1: first 162 positions per block for training and final
  40 positions per block for validation.
- Replay block 6: locked and unused by this experiment.
- Twelve-step windows are left-padded within each replay block and never cross
  a block boundary.
- Feature maxima are computed only from training rows.

## Compared models

- v0: shared two-layer per-host Transformer and common detection/classification
  heads.
- v1: v0 plus an ordinary learned softmax router, four
  `64 -> 128 -> 64` GELU experts, all-expert weighted mixing, and a learnable
  MoE residual gain initialized to 0.25.

The four-expert setting was selected because this validation corpus contains
only 324 training intervals.  It retains the intended ordinary-router role
while reducing over-parameterization.  Identical seed initialization gives
v0 and v1 identical common parameters before v1's optional branch is built.

## Training and resource limits

- Seeds: 1, 2, 6.
- AdamW, learning rate `3e-4`, weight decay `1e-4`, batch size 32.
- Maximum 35 epochs, patience 10, five-epoch warmup, cosine decay, gradient
  clipping 1.0.
- One process at a time; three CPU threads; `num_workers=0`; float32;
  Windows priority `BelowNormal`; no `torch.compile`.
- Training refuses to start an epoch below 4.5 GiB available RAM or 20 GiB
  free F: disk space.

## Validation results

| Variant | Seed | Best epoch | F1 | HR@100 | NDCG@100 |
|---|---:|---:|---:|---:|---:|
| v0 | 1 | 7 | 0.4343 | 0.3600 | 0.2893 |
| v0 | 2 | 16 | 0.4597 | 0.3800 | 0.3168 |
| v0 | 6 | 20 | 0.4858 | 0.4400 | 0.3850 |
| v1 | 1 | 16 | 0.4830 | 0.4400 | 0.4130 |
| v1 | 2 | 15 | 0.4461 | 0.3400 | 0.3175 |
| v1 | 6 | 22 | 0.4826 | 0.4800 | 0.5191 |

| Mean | F1 | HR@100 | NDCG@100 |
|---|---:|---:|---:|
| v0 | 0.4600 | 0.3933 | 0.3304 |
| v1 | 0.4705 | 0.4200 | 0.4166 |
| v1 - v0 | **+0.0106** | **+0.0267** | **+0.0862** |

The mean relation `v0 < v1` holds for all three metrics.  The mean F1 gain
also exceeds the plan's 0.005 noise-margin rule.  Seed 2 regresses, which is
allowed by the agreed mean-only criterion.

## Resource observations

- Total elapsed training time: 93.7 seconds across six serial runs.
- Maximum process RSS: 0.309 GiB.
- Minimum available system RAM at epoch boundaries: 6.807 GiB.
- No Python training process remained after completion.

## Artifacts and next boundary

- v0 summaries/checkpoints:
  `artifacts/ftmoe_ablation/existing_data/iteration_002_default/`
- accepted v1 summaries/checkpoints:
  `artifacts/ftmoe_ablation/existing_data/iteration_003_v1_e4_gain025/`
- runner: `train_ftmoe_ablation_existing.py`
- model: `recovery/PreGANSrc/src/ftmoe_ablation.py`

This establishes only the first validation segment.  It is not a full
v0--v4 chain and not a locked-test result.  The next experiment must add or
replace only the v2 routing module and compare its three-seed mean with this
accepted v1 configuration.  Do not evaluate replay block 6 until the model
chain and hyperparameters are frozen.
