# 项目最新上下文（新对话入口）

> **最新覆盖说明（2026-09-05，历史复用审计与协议 013/014 完成）：以下旧进度条目按时间保留，以本条为准。**
> 用户要求复习可复用历史结果并继续实验。`FTMOE_HISTORY_REUSE_AUDIT.md` 和 `artifacts/ftmoe_end_to_end/history_reuse_audit.json` 已对五组完整物理配置及已有校准组按新主链重新比较。优先候选为 `physical_lr0003_e30` 的协议 005 重评估 B_best：v0/v1/v2/v3/v4 F1=0.546070/0.596316/0.898028/0.893558/0.903615；A_last 不通过，配对区间跨零，尚不能宣称成功。
> 旧源码哈希、数据、训练更新逻辑和五版本初值/单步更新逐位一致性已核验；报告 `history_runtime_compatibility.json`。旧组最佳权重须读取 `diagnosis_reassessment/physical_lr0003_e30` 指定的每轮 checkpoint，不能使用原 best.pt 代替。
> 协议 013 三种子门控对照及协议 014 新种子 17/42 的五版本和门控控制全部完成，本轮新增 15 个独立全模型 30 轮训练。新运行 `gated_fusion_lr0003_e30`、`historical_confirm_lr0003_e30`、`historical_gated_confirm_lr0003_e30` 均已结束。五种子 B F1（v0/v1/v2/v3/v4/gated）=0.525479/0.567550/0.901334/0.894437/0.905134/0.903579，诊断=0.860048/0.860922/0.936297/0.962851/0.972003/0.970907。
> 五种子三项主比较均值方向仍为正，但 v4-v2、v4-gated F1 增量为 0.003799、0.001554，未达原登记的 0.005，条件区间跨零。新种子中 gated 检测均超过 attention，v1 诊断也未改善，因此初始化确认未通过，不满足冻结测试资格。结果仍有效且可作探索性报告，不能称为稳健贡献已证明。`comparison_014_complete.json`、`FTMOE_HISTORICAL_CONFIRMATION.md` 和 `figures/historical_confirmation_014.png/.svg` 已生成，图已检查。测试 201–205 仍未生成。
> 协议 011 的 60 轮门控和阈值校准已全部完成且没有通过。完整 attention / gated 的原始 B F1=0.928921/0.927230、诊断=0.991505/0.993187；校准 B F1=0.935360/0.935150。简单融合 v3 校准 B F1=0.954232，不能省略这一反例。
> 协议 012 的 source_attention 三种子已完成，B F1=0.926223、诊断=0.991259。source_gated 尚未训练，因用户优先历史复用而暂后排，仍须完成并报告；不得将协议 012 记为已完整验收。评估脚本 `evaluate_ftmoe_source_alignment.py` 已准备，须待两臂训练及协议 008 校准全部完成后执行。当前没有训练进程运行。
> 选模诊断 `FTMOE_HISTORICAL_SELECTION_DIAGNOSTIC.md` 确认部分早期 v0/v1 几乎总预测 CPU：始终预测 CPU 的开发诊断准确率为 0.898224；S 实际为 (F1+2×资源准确率)/3，偏好部分检测和 macro F1 更低的早期点。此为已测得的选模取舍，不是泄漏证明。后续若研究类别平衡损失或 macro 选模，必须登记为新方案、对所有模型同等应用；不能修改当前确认结论或挑掉不利种子。

> **2026-09-05 后续进展：当前正在执行独立初始化、全模型联合训练的新消融实验。**
> 用户要求持续按“分析原因—设计方案—修正—复验”迭代，允许修改模型、数据和模拟器，直至获得消融链及接近论文的指标。
> 当前工作记录见 `FTMOE_END_TO_END_EXPERIMENT_LOG.md`，计划见 `FTMOE_END_TO_END_ABLATION_PLAN.md`，产物在 `artifacts/ftmoe_end_to_end/`。
> 新开发重放为 31、101、102，测试种子预留 201–205，尚未生成。旧测试 37、41、47 不参与本轮。
> 首组 `initial_lr0003` 已完成：验证最优三项均值严格链成立，但 v0→v1、v3→v4 的 F1 增量不足 0.005；公共停止轮次协议 002 未通过登记标准。
> 后续发现并修复了 `OfflineTraceWorkloadV2` 的容器生命周期/trace 绑定错误；协议 003 重建数据全部通过需求对齐检查。第二组旧数据学习率试验 `initial_lr001` 已主动停止并保留部分结果。
> 协议 004 数据已生成并通过物理一致性检查：真实调度前物理主机输入、实际过载资源类别，CPU_CAP_SCALE=0.8、RAM_SCALE=2、DISK_SCALE=1000、DISK_CAP_SCALE=0.25。`physical_lr0003_e30` 的 15 个统一 30 轮全模型训练已完成。
> 协议 005 修正排名口径：TranAD 官方 `@100%` 是逐异常样本的资源诊断，旧全局 top-100 检索指标不能与之混用。当前单标签数据的 HR@100%=NDCG@100%=top-1 资源准确率。保留旧结果，用保存的每轮混淆矩阵重算验证选择；测试 201–205 仍未生成。
> 物理数据三组公共学习率的 45 个训练及协议 007 的统一 60 轮 15 个训练全部完成，公共学习率 0.003，固定模型种子 1/2/6。60 轮 A/B 均未通过：前段诊断、中段检测回落。完整目标尚未通过。
> 协议 009 八个上下文 pilot 已完成，none/local/global 的五版本平均 B 最优 S=0.91601/0.91190/0.90679，原模型胜出。协议 010 八个 dropout pilot 已完成，0/0.1/0.3 的 S=0.91601/0.92022/0.91718，按规则选择 0.1。正在执行 `expert_dropout01_lr003_e60`：v1–v4、固定种子 1/2/6、60 轮，独立初始化、全参数联合训练；v0 无专家，复用原完整 60 轮控制并保留哈希来源。单种子 pilot 检测链仍失败，完整目标尚未达标。协议 008 阈值校准暂缓。测试 201–205 仍未生成。
> 下文是此前已冻结的逐级训练结果，不能当作新全模型实验已经成功，也不要启动 QoS。
> **用户最新澄清：不再强求 v2、v3、v4 逐级单调。协议 011 主链改为 v0、v1、v2、完整 v4；v3 保留为简单融合对照。dropout=0.1 的 60 轮全组已完成并核验汇总到 `expert_dropout01_lr003_e60_chain`，v4 最佳 F1=0.92892 仍低于 v2=0.93172。正在执行 `gated_fusion_lr003_e60`，同参数量门控融合替换多头注意力、三固定种子全模型重训。去除整套图分支及其依赖融合对应 v2，不能称为只移除图编码器。新评估器为 `evaluate_ftmoe_branch_development.py`；测试仍未生成。旧失败不改写，新方案也尚未通过。**

更新日期：2026-09-05

## 1. 用户目标与当前状态

本项目对应论文 `C:\Users\Lenovo\Desktop\AAAI_AuthorKit25_AnonymousSubmission.pdf`。用户希望复现论文方法，当前阶段优先保证常见论文式消融关系：删除模块后性能下降。模型结构和超参数不要求与论文完全一致，同类功能模块即可；允许调整模型、数据和模拟器。计算必须给用户电脑保留日常轻量工作的空间。

以下是此前冻结增量训练的已完成结果，**不代表当前独立全模型实验已经通过**。此前三项均值满足严格消融链：

`v0 < v1 < v2 < v3 < v4`

最终 v4 的锁定测试结果为 F1 0.90551、HR@100 0.99889、NDCG@100 0.99861。论文参考值为 F1 0.8766、HR@100 0.6496、NDCG@100 0.6021。当前 F1 与论文相差 +0.02891；HR/NDCG 因数据、标签和指标定义差异，不能直接作为优于论文的证据。

## 2. 最终模型

实现文件：`recovery/PreGANSrc/src/ftmoe_ablation.py`

- v0：两层逐主机 Transformer 时间编码器。
- v1：增加 4 专家普通 softmax router；所有专家参与加权。
- v2：保留 v1，再增加资源感知 EAGate 稀疏修正。EAGate 使用余弦门控、`tanh` 阈值、STE、至少 Top-1 回退、最多 4 个专家和温度下限，避免无专家及门控无梯度。
- v3：增加调度感知图编码器。输入包括调度后资源聚合、占用、迁移方向和主机容量。
- v4：增加跨路径 CMHA；时间/MoE 路径为 Q，图路径为 K/V，通过独立 adapter 修正检测和类别 logits。

每个新增模块的输出 adapter 零初始化。新版本从前一级 checkpoint warm-start，首次更新前输出保持嵌套一致。EAGate 使用仿真步执行前可见的需求和调度，不读取结果标签。

## 3. 最终数据与隔离

最终数据目录：`recovery/PreGANSrc/data/ftmoe_replay_holdout_final`

数据由同一模拟器产生的 9 个完整重放块组成，每块 202 interval，没有按结果筛选行：

- 训练重放种子：42、1、6、17、23；
- 开发验证种子：31；
- 锁定测试种子：37、41、47；
- 模型随机种子：1、2、6；
- 12 步窗口不跨重放边界；
- 归一化只使用训练块；
- 最终均值按 3 个模型种子乘 3 个测试重放种子的 9 个单元等权计算。

标签策略：放置后过载标签在块内做一步容差膨胀；类别阈值只在训练块按第 98 百分位拟合；RAM/Disk 放大系数均为 1.5。完整来源、数组形状和 SHA-256 位于最终数据目录的 `manifest.json`。

## 4. 已接受训练运行

训练器：`train_ftmoe_ablation_existing.py`

公共设置：float32、batch size 32、AdamW、weight decay `1e-4`、5 epoch warmup、余弦衰减、梯度裁剪 1.0、4 个专家。

| 版本 | 运行目录 | 最大 epoch | 学习率 | 检测/分类权重 | 排名损失 | 训练范围 |
|---|---|---:|---:|---|---:|---|
| v0 | `final_003_v0_budget3` | 3 | 0.0003 | 0.90 / 0.05 | 0 | 全模型 |
| v1 | `final_004_v1_from_budget3` | 30 | 0.003 | 0.50 / 1.50 | 0.5 | 仅普通 MoE |
| v2 | `final_005_v2` | 1 | 0.00002 | 0.70 / 0.30 | 0 | 仅 EAGate |
| v3 | `final_007_v3_budget1` | 1 | 0.001 | 0.90 / 0.10 | 0 | 仅图模块 |
| v4 | `final_008_v4_stage1` | 30 | 0.001 | 0.70 / 0.30 | 0.5 | 仅 CMHA |

运行目录根路径：`artifacts/ftmoe_ablation/replay_validation`。每个版本保留模型种子 1、2、6 的 `best.pt`、epoch 日志和训练摘要。

重要限制：各版本使用不同训练预算和损失权重。结果符合“单调链优先”的当前要求，但不是所有超参数完全一致的受控架构消融。论文写作必须披露。若以后要求更强的模块因果归因，需要另做统一预算补充实验。

## 5. 最终结果

锁定测试 9 单元均值 ± 样本标准差：

| 版本 | F1 | HR@100 | NDCG@100 |
|---|---:|---:|---:|
| v0 | 0.27060 ± 0.07604 | 0.25333 ± 0.18118 | 0.23223 ± 0.15863 |
| v1 | 0.41529 ± 0.05177 | 0.56667 ± 0.12155 | 0.58685 ± 0.12983 |
| v2 | 0.50838 ± 0.09917 | 0.90000 ± 0.07228 | 0.92275 ± 0.05747 |
| v3 | 0.54759 ± 0.11405 | 0.94222 ± 0.06399 | 0.95496 ± 0.05053 |
| v4 | 0.90551 ± 0.05256 | 0.99889 ± 0.00333 | 0.99861 ± 0.00418 |

相邻 F1 增量：0.14469、0.09309、0.03921、0.35792。最小值高于预设门槛 0.005。按每个测试重放分别对模型种子取均值时，F1 链也全部单调。

正式结果文件：

- `artifacts/ftmoe_ablation/formal_results_final_multireplay/config_lock.json`
- `artifacts/ftmoe_ablation/formal_results_final_multireplay/test_summary.json`
- `artifacts/ftmoe_ablation/formal_results_final_multireplay/test_per_model_and_replay_seed.csv`

`config_lock.json` 在首次测试前写入数据、代码和全部 checkpoint 哈希。最终测试只运行过一次。不要使用种子 37、41、47 继续调参，也不要覆盖该目录。若模型再次变化，必须生成新的未使用重放种子和新结果目录。

## 6. 模拟器改动

本轮相关改动：

- `dump_replay.py`：保存仿真步前容器需求和主机容量，支持固定调度重放，限制 3 线程并设置 `BelowNormal` 优先级。
- `simulator/workload/OfflineTraceWorkloadV2.py`：支持 `DISK_SCALE`。
- `simulator/host/Host.py`：允许将超容量 Disk 作为可观测故障状态。
- `simulator/environment/RPiEdge.py`：支持 `DISK_CAP_SCALE`。
- `build_ftmoe_replay_holdout_dataset.py`：构建最终 9 块数据、仅用训练块拟合类别阈值并写入来源哈希。

## 7. 计算约束

使用 Python：`D:\Anaconda\envs\dynmoe\python.exe`。

- 同时只运行一个训练或 QoS 进程；
- `OMP_NUM_THREADS=3`、`MKL_NUM_THREADS=3`、`OPENBLAS_NUM_THREADS=3`；
- PyTorch intra-op 3 线程、interop 1 线程；
- DataLoader `num_workers=0`；
- Windows 进程优先级 `BelowNormal`；
- 可用 RAM 低于 4.5 GiB 或 F 盘低于 20 GiB 时停止；
- 最终训练峰值 RSS 约 0.28 GiB。

## 8. 下一阶段：QoS

检测消融已经完成，闭环 QoS 尚未正式执行。下一对话应先阅读本文件和 `FTMOE_ABLATION_FINAL_REPORT.md`，然后：

1. 冻结本轮 checkpoint、检测阈值 0.5、恢复策略和迁移约束。
2. 对 v0 至 v4 使用相同 workload、初始放置、调度种子和到达序列。
3. 增加无恢复、原始 GOBI 和 oracle 检测控制组。
4. 先运行 `2 seeds × 50 intervals` 冒烟测试，再运行 `5 seeds × 100 intervals` 正式测试。
5. 报告 CPU/RAM/Disk 过载、过载 host-step、平均/P95 响应时间、能耗、SLA 违约、迁移数、迁移开销和推理延迟。
6. QoS 子指标不要求全部形成消融链；要求完整 v4 综合最好，并解释召回、迁移、能耗和 SLA 权衡。
7. 不得根据锁定测试种子 37、41、47 调整检测模型。

## 9. 保留文件入口

- `FTMOE_ABLATION_FINAL_REPORT.md`：完整实验说明、验证结果、测试结果、限制和 QoS 协议。
- `FTMOE_ABLATION_EXECUTION_PLAN.md`：原始验收口径和执行方案；最终报告优先。
- `full_paper_text.txt`：论文抽取文本。
- `recovery/PreGANSrc/src/ftmoe_ablation.py`：最终模型。
- `train_ftmoe_ablation_existing.py`：最终训练器。
- `evaluate_ftmoe_final_multireplay.py`：一次性锁定评估器。
- `build_ftmoe_replay_holdout_dataset.py`：最终数据构建器。
- `dump_replay.py`：模拟器数据导出器。

旧 checkpoint、失败运行、重复数据集、旧日志、候选数组、旧评估器和旧上下文已按用户要求删除。失败迭代的关键数值仍记录在 `FTMOE_ABLATION_FINAL_REPORT.md`，但旧模型文件不再可恢复。
