---
name: ftmoe-qos-overload-status
description: "2026-08-23 上下文交接：当前主线 = QoS 过载标签（tol1 全链定稿）；历史 v9-boost 主线已废弃"
metadata:
  node_type: memory
  type: project
  modified: 2026-08-23T00:00:00.000Z
---

# 上下文交接（2026-08-23，新对话必读）

**当前权威上下文 = `PROJECT_CONTEXT.md`（2026-08-23 精简版）**。本文件只做指针与增量说明。

## 用户核心约束（跨对话必须遵守）

单调链 = 后一模型在前一模型**结构不变**基础上加新模块，**每个新模块必须有提升**
（v0 < v1b < v2c2 < v3b2 < v4c1 严格单调）；消融可逆。可改模块/调数据集，但链必须成立。
（当前结构上满足嵌套+零门可逆；数值上前段等价、后段机制增益——严格链未达成，见上下文。）

## 当前主线：QoS 过载标签（取代本文件旧内容）

- **最终定稿**：`qos_overload_ms_tol1` 数据集 + 全链 15 runs
  （ckpt：`checkpoints_qos_overload_ms_tol1/`）
- **最终结果**（3 种子均值）：检测 F1 v0 .4287 / v1b .4117 / v2c2 .4122 /
  v3b2 .6855 / v4c1 .6792；分类 HR@100 v0 .3781 / v1b .3495 / v2c2 .4221 /
  v3b2 .5959 / v4c1 .5986（分类接近论文 .6496，后段单调；前段等价，严格链未达成）
- **关键机制**：FREEZE 强监督（v3b2/v4c1）、tol1 标签扩展（±1 步）、画像类分类标签
  （阈值注入 ram/disk）、在线协议 ONLINE_TUNE=0
- **坑**：磁盘满致训练被杀/ckpt 损坏；3 并行 v4c1 OOM；eval 与训练 env 必须一致；
  容差评估不改标签无效；RULE_AUX 需 GRAPH_AUX>0 才生效

## 历史（已废弃，仅存档）

- 2026-08-20 的 rulefeat 高分方案 / v11-v17 数据迭代 / "三选一待决策" 全部过时
- 详细历史见 `notes_v9_experiment.md` 与 `PROJECT_CONTEXT_full.md`
