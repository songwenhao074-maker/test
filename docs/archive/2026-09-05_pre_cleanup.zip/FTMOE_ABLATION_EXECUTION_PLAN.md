# FT-MoE 消融复现执行方案

> **执行状态（2026-09-05）：已达到验收条件。** 最终执行记录、参数、失败实验和限制见
> `FTMOE_ABLATION_FINAL_REPORT.md`。本文件第 1 节的验收口径仍有效；后续初始设想若与最终报告冲突，
> 以最终报告和已冻结的 `config_lock.json` 为准。最终方案使用 5 个完整训练重放块、1 个开发验证
> 重放块和 3 个锁定测试重放块；测试均值按 `3 个模型种子 × 3 个重放种子` 等权计算。

## 1. 目标与验收口径

目标是得到结构清晰、可解释且稳定的五级消融链：

`v0 < v1 < v2 < v3 < v4`

正式结果以随机种子均值判断，同时满足：

- F1、HR@100、NDCG@100 三项均严格单调；
- 相邻模型平均 F1 增量至少 0.005，避免把随机波动当成模块收益；
- 单个种子允许退化，不把逐种子同向作为验收条件；
- 最终 v4 目标：F1 >= 0.86、HR >= 0.63、NDCG >= 0.58；
- 超参数和 checkpoint 只用验证集选择，测试集在配置锁定后运行一次。

## 2. 五级模型定义

公共输入为最近 12 个 interval、16 个 host、每 host 7 个资源特征。除表中变化外，隐藏维度、检测头、分类头、训练预算和数据完全一致。

| 模型 | 相对前一级的唯一变化 | 说明 |
|---|---|---|
| v0 | 时间序列基线 | 紧凑逐主机 Transformer，不读取调度矩阵 |
| v1 | 新增 MoE + 普通 router | router 为可学习 softmax router，所有专家参与加权 |
| v2 | 普通 router 替换为 EAGate | STE Top-any，逐样本激活 1 到 4 个专家 |
| v3 | 新增调度感知图编码器 | 从相邻调度直接构造有向迁移边 |
| v4 | 新增跨路径 CMHA | `Q=MoE 输出，K/V=图输出`，保留 v3 原融合 |

删除 v4 的 CMHA 即得到 v3；删除 v3 的图分支即得到 v2；将 v2 的 EAGate 换回普通 router 即得到 v1；删除 v1 的 MoE 即得到 v0。

## 3. 模块实现

### 3.1 公共时间编码器

- 输入：`[batch, 16, 12, 7]`；
- reshape 为 `[batch*16, 12, 7]`；
- `Linear(7, 64)` + 两层 Transformer Encoder；
- 4 heads，dropout 0.1；
- last-token 与 mean-pooling 求平均；
- 输出：`[batch, 16, 64]`。

全流程使用 float32，不再使用当前的 float64 和大型 flatten decoder。

### 3.2 v1：普通 router MoE

- 专家数：4（后续数据量扩大时可重新验证 8）；
- 每个专家：`64 -> 128 -> 64`，激活函数 GELU；
- router：`Linear(64, 8)` 后接 softmax；
- 输出：`sum(router_prob[g] * expert_g(x))`；
- MoE 残差增益初始值为 0.25，并可学习；
- 所有专家都参与，不使用阈值、Top-K、动态增删；
- 使用轻量负载均衡损失，权重 0.01，防止长期只使用一个专家。

该 router 是最普通的可学习 MoE router，训练稳定，也能让 v1 与 v2 的差异只集中在路由机制。

### 3.3 v2：EAGate Top-any

- 与 v1 共用相同的 4 个专家和专家网络；
- 余弦相似度：`s = cosine(x, expert_key)`；
- 阈值：`tau = tanh(theta)`，与余弦相似度处于同一数值空间；
- soft mask：`sigmoid((s-tau)/temperature)`；
- hard forward：无专家通过时选 Top-1，超过 4 个时选 Top-4，否则选全部通过阈值的专家；
- backward：`hard_mask + soft_mask - stop_gradient(soft_mask)`；
- temperature 从 1.0 退火到 0.2；
- 初期平均激活数目标为 2 到 4。

正式消融阶段固定专家总数。在线专家增删只在后续在线学习实验中启用。

### 3.4 v3：调度感知图编码器

对每个 container 比较相邻调度：

```text
src = argmax(schedule[t-1, container])
dst = argmax(schedule[t, container])
src != dst 时添加 src -> dst 迁移边
```

- 添加 host 自环；
- 使用 PyTorch masked multi-head graph attention，不依赖 DGL；
- 保留完整 `[batch, 16, 64]` 图向量，不再压缩成单个标量；
- v3 融合：`z = z_moe + gamma_graph * z_graph`；
- `gamma_graph` 初始为 0.05，可学习；
- 图辅助损失最大权重 0.05，不使用当前 `graph_lr=0.01` 的强制配方。

### 3.5 v4：跨路径 CMHA

- `Q = LayerNorm(z_moe)`；
- `K = V = LayerNorm(z_graph)`；
- hidden dimension 64，4 heads，dropout 0.1；
- `z_v4 = z_v3 + gamma_cmha * CMHA(Q,K,V)`；
- `gamma_cmha` 初始为 0.05，可学习。

CMHA只增加跨路径交互，不替换 v3 已有路径，因此删除它后模型严格退化为 v3。

### 3.6 检测和分类头

- 检测头输出 raw logits，使用带类别权重的交叉熵或 focal loss；
- 分类采用 3 个可学习 prototype，维度 Q=8；
- embedding 和 prototype 均做 L2 normalization；
- 使用负平方距离 logits 的交叉熵；
- 可增加权重 0.01 的 prototype separation loss；
- 不再使用当前可能截断负样本梯度的手动 triplet 更新。

主损失初始设置：

`L = 0.55*L_det + 0.35*L_cls + 0.10*L_proto + 0.01*L_balance`

v3/v4 的模块辅助损失单独记录，且权重不得超过 0.05。

## 4. 模拟数据和划分

优先使用仓库现有数据集 `recovery/PreGANSrc/data/qos_overload_ms_tol1`，不再用临时生成数据替代：

- 数据由 3 个 GOBI 重放块组成，每块 202 interval；重放种子依次为 42、1、6；
- 结构迭代只使用前两个重放块；每块时间位置 0--161 用于训练，162--201 用于验证；
- 第三个重放块保持锁定，不参与结构和超参数选择；
- 12 步窗口不得跨越 202 行的重放边界；
- 归一化统计量只从训练行计算；
- 标签使用现有 `labels_overload_class.npy`，其中 0 表示正常，1/2/3 表示 CPU/RAM/Disk 类别。

该数据集三个重放块共享资源 trace，但调度和标签不同。v0--v2 不读取调度，因此前段可达到的性能存在信息上限；v3 引入图分支后才获得区分冲突样本所需的调度信息。最终结果必须明确披露这一点。

## 5. 训练配置

- optimizer：AdamW；
- batch size：32；
- 公共学习率：`3e-4`；
- weight decay：`1e-4`；
- warmup：5 epochs；
- cosine decay 最低到 `1e-5`；
- 最大 60 epochs；
- early stopping patience：8；
- gradient clipping：1.0；
- 第一轮验证种子：`1, 2, 6`；资源允许时再补 `17, 42`。

五个模型正式结果全部从头独立训练。同一种子下公共层使用相同初始化；不使用前一级蒸馏，不读取测试集，不为单个模型单独增加训练轮数。

## 6. 分阶段执行与决策门槛

### 阶段 A：结构筛选

- 使用现有数据集的固定训练/验证划分；
- 种子 1、2、6；
- 最多 25 epochs；
- 只判断消融方向。

某一级没有增益时，只调整该模块及对应模拟机制，不进入完整训练。

### 阶段 B：完整验证

- 使用完整训练集和验证集；
- 先运行种子 1、2、6；
- 验证均值满足严格单调后锁定结构和超参数。

### 阶段 C：正式测试

- 补种子 17、42；
- 配置冻结后运行一次测试集；
- 报告均值、标准差及相邻变体的配对置信区间。

若测试结果不单调，应如实报告；不得再用测试集反向调整参数。

## 7. 计算资源限制

- 同时只运行一个训练或 QoS 进程；
- `OMP_NUM_THREADS=3`；
- `MKL_NUM_THREADS=3`；
- `OPENBLAS_NUM_THREADS=3`；
- `torch.set_num_threads(3)`；
- `torch.set_num_interop_threads(1)`；
- Windows 进程优先级设为 `BelowNormal`；
- DataLoader `num_workers=0`；
- 可用内存低于 5 GB 时不启动下一 epoch，低于 3.5 GB 时安全停止；
- 不启用 `torch.compile`；
- 每次训练只保存 best 和 final checkpoint；
- F 盘剩余空间低于 20 GB 时不启动训练。

所有 5 个模型和 5 个种子串行执行。训练调度器必须支持断点续跑，并在每个 epoch 之间检查内存和磁盘。

## 8. QoS 复现方案

### 8.1 模块消融 QoS

- v0 到 v4 检测器全部冻结；
- 使用相同 workload seed、初始状态和 GOBI 原始调度；
- 使用同一个冻结的恢复策略或结构相同、独立初始化且训练预算相同的 GAN；
- 禁止不同模型共享在线 GAN checkpoint；
- 先运行 `2 seeds x 50 intervals` 冒烟测试，再运行 `5 seeds x 100 intervals` 正式实验。

### 8.2 在线学习消融

只比较完整 v4：

- v4 without online tuning；
- v4 with online tuning。

在线标签来自无恢复 shadow simulator。专家动态调整使用固定 12-expert pool 和 active mask，初始启用 4 个；不在运行时修改 ModuleList。

### 8.3 QoS 公平性和指标

- 每 interval 的 GAN 更新机会相同，不能由检测触发次数决定训练次数；
- 所有迁移先进行 CPU/RAM/Disk 可行性检查；
- 限制单 interval 最大迁移数；
- 修正并验证 SLA 计数、能耗单位和时间对齐；
- 同时报告 CPU、RAM、Disk、过载 host-step、平均/P95 响应时间、能耗、SLA 违约、迁移次数、迁移开销和推理时间。

不要求所有 QoS 子指标随 v0 到 v4 逐项严格单调；要求完整 v4 的综合 QoS 最好，并单独解释检测召回、迁移次数与能耗之间的权衡。

## 9. 预计实施顺序

1. 新建统一、batch 化的模型文件，避免继续维护多套互相矛盾的 FT-MoE 类；
2. 实现 v0 与公共检测/原型分类头；
3. 实现 v1 普通 softmax router MoE；
4. 实现 v2 STE EAGate；
5. 实现 v3 直接迁移图编码器；
6. 实现 v4 跨路径 CMHA；
7. 修复并统一训练、评估和指标实现；
8. 使用现有数据集的固定训练/验证划分验证方向；
9. 锁定模型配置后评估第三个重放块；
10. 顺序完成后续消融和 QoS 实验。
