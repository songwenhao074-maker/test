# FT-MoE 消融执行记录与修正清单

执行日期：2026-09-04  
对应方案：[FTMOE_ABLATION_EXECUTION_PLAN.md](FTMOE_ABLATION_EXECUTION_PLAN.md)

## 本次结论

**正式消融实验没有启动，因而没有可报告的 v0--v4 测试结果。** 仓库当前的
训练、数据和评估实现不是该方案定义的实验；直接将它们的历史 checkpoint 或输出
当作方案结果，会违反方案的模型、数据划分和测试集冻结要求。

已完成一项隔离的运行时预检，确认当前旧链路及其可用 Python 环境能够执行。这仅是
环境/数据管线检查，不能用于验收或与计划中的指标比较。

## 已执行的预检

### 环境

- Python：`D:\Anaconda\envs\dynmoe\python.exe`。
- PyTorch：2.4.1+cpu；DGL：2.0.0；NumPy：1.19.2。
- `train_progressive_v2.py`、`models_v2.py`、`eval_holdout.py` 和
  `run_chain_overload.py` 已通过 `py_compile`。
- F: 剩余空间约 125.2 GiB，满足方案所要求的 20 GiB 启动阈值。
- 运行限制：`OMP_NUM_THREADS=MKL_NUM_THREADS=OPENBLAS_NUM_THREADS=4`。

### 命令与产物

使用历史数据集 `qos_overload_ms_tol1` 执行了 **v0、seed 1、单 epoch** 的隔离预检：

```powershell
$env:DATA_VERSION='qos_overload_ms_tol1'
$env:LABEL_MODE='overload'
$env:TRAIN_ROWS='404'
$env:V2_CKPT='logs/ftmoe_plan_preflight_ckpts/'
$env:NUM_EPOCHS='1'; $env:EVAL_EVERY='1'; $env:SAVE_EPOCH='1'
$env:FORCE='1'
$env:OMP_NUM_THREADS='4'; $env:MKL_NUM_THREADS='4'; $env:OPENBLAS_NUM_THREADS='4'
& 'D:\Anaconda\envs\dynmoe\python.exe' -u train_progressive_v2.py v0 1
```

观测值：

- 输入：404 个窗口，754 个异常 host-step（11.66%）。
- 单轮训练耗时约 19 秒；训练日志的总损失为 `12.4650139883`
  （`ALoss=16.3358383821`、`TLoss=-3.8708243938`）。
- 隔离产物：
  `logs/ftmoe_plan_preflight_ckpts/simulator_FTMoE_v0_16_v2_s1.ckpt` 与
  `logs/ftmoe_plan_preflight_ckpts/simulator_FTMoE_v0_16_v2_s1_snap1.ckpt`。
- 旧 `eval_holdout.py` 固定请求 `*_snap85.ckpt`，因此不能读取这个单轮快照；这也
  是正式训练调度/评估接口需要修复的证据。

## 发现的正式实验阻塞项

| 方案要求 | 当前实现/数据 | 影响与必须修正 |
| --- | --- | --- |
| 50 episode、每个 200 interval，共 10,000；35/5/10 episode 划分 | 可用历史数据分别为 `qos_overload_ms_tol1` 的 606 行和 `version2` 的 10,002 行；没有 episode manifest 或固定的 train/val/test 划分 | 新建数据生成器、`manifest.json` 和三份不重叠数据索引；禁止通过行号临时切分替代 episode 划分。 |
| shadow simulator 的下一 interval 真实标签、25--30% 正样本、五种事件组成 | 现有 `LABEL_MODE=overload` 使用历史 GOBI 回放标签；预检集正样本率为 11.66% | 生成阶段必须逐 episode 保存无恢复 shadow 状态、标签来源、事件类型、资源类别和 seed，并在生成后自动校验占比。 |
| `[B,16,12,7]`，float32，64 维、两层/四头 Transformer | `models_v2.py` 固定 3 步窗口、float64、旧 GAT/Transformer 解码器；训练脚本显式调用 `.double()` | 新的批处理模型须只接受计划定义的张量；移除 `.double()` 和旧 flatten decoder。 |
| v0 不读取调度矩阵 | v0 的 `forward(t, s)` 仍将 `s` 传给旧 `encode`；接口没有禁止调度依赖 | 将时间编码器与调度图分支分离；为 v0--v2 增加测试，断言改变 schedule 不改变输出。 |
| v1：8 个 `64→128→64` 专家 + `Linear(64,8)` softmax | 当前 v1b 使用旧 `_MoE_Progressive`、默认 12 专家和余弦 score；不是规定的 router | 新建普通 router，所有专家参与，并实现权重 0.01 的负载均衡损失。 |
| v2：余弦相似度与 `tanh(theta)` 同域、STE、每样本 1--4 激活、1.0→0.2 退火 | 当前可运行 v2c2 是 `softgate`，无 hard forward；另一个旧 `eagate` 默认最多 8，且阈值经 sigmoid 后不在余弦域 | 以一个明确的 `EAGate` 实现替换；记录每 epoch 平均激活数与 temperature，并添加 0/超过 4 个候选的单元测试。 |
| v3：相邻调度的 `src→dst` 迁移边 | 当前图编码器对 dense schedule 使用共置 `SᵀS`，对迁移格式重构共置图，并非规定的相邻迁移边 | 按 `argmax(S[t-1,c])→argmax(S[t,c])` 构造有向图与自环；保留 `[B,16,64]`，使用 masked 4-head GAT。 |
| v4：`Q=MoE`，`K=V=Graph` 的 64 维、4 头 CMHA | 当前 v4c1 是 host-axis self-attention；v4c2 的 K/V 来自时间步原始特征，均不符合 | 仅保留计划所述 CMHA，`z_v4=z_v3+gamma_cmha*CMHA`；添加断言/测试，禁用 CMHA 后输出与 v3 一致。 |
| 原型分类：3 个可学习、Q=8、L2 normalize、负平方距离 CE、separation loss | 当前 prototype 是不参与 autograd 的 Python tensor 列表，训练使用手动 triplet 更新；历史配置常为 Q=2 | 改成 `nn.Parameter(3,8)`，使用规范的距离 logits 和可选 separation loss。 |
| AdamW、lr 3e-4、batch=32、warmup 5、cosine、60 epoch、patience 8、clip 1.0 | 当前逐样本训练、lr 1e-4、无 batch/warmup/cosine/early stopping/gradient clip | 实现 batch DataLoader（`num_workers=0`）、验证集早停和 scheduler；所有选择仅依据 validation。 |
| 每 epoch 检查 RAM/磁盘、断点续跑、只留 best/final | 当前脚本每 epoch 覆盖保存，但不检查内存/磁盘，也不能恢复；评估器硬编码 `snap85` | 新调度器应原子保存 `last`、`best`、训练状态和 RNG 状态；每 epoch 检查 <5/<3.5 GiB 内存及 <20 GiB 磁盘。 |
| 阶段 A/B/C 的 2/3/5 seed 及冻结测试 | 当前运行器只覆盖历史三种 seed `1,2,6`，没有 validation lock 与 17/42 | 新 runner 必须串行执行，并分别写 `screening`、`validation`、`test` 结果；配置 hash 在进入 C 前冻结。 |
| HR@100、NDCG@100 及相邻变体配对 CI | 旧评估将单类标签退化为 top-1，并且固定第 85 轮 checkpoint | 使用计划定义的标签与可学习原型计算指标；输出逐 seed CSV 和 bootstrap/paired CI。 |
| QoS：先 2×50 冒烟，再 5×100 正式；冻结探测器、统一恢复预算 | 现有 `run_qos_probe_chain.py` 是 3 seed × 60 interval 的历史过载方案 | 仅在检测实验锁定后新建 QoS runner；保存每 interval 的资源、响应、能耗、SLA、迁移和推理耗时，并禁止共享在线 GAN checkpoint。 |

## 建议的修正顺序

1. 新建独立实现，避免继续修改旧 `models_v2.py`：
   `recovery/PreGANSrc/src/ftmoe_ablation.py`、
   `build_ftmoe_ablation_dataset.py`、`train_ftmoe_ablation.py`、
   `evaluate_ftmoe_ablation.py` 和 `run_ftmoe_ablation.py`。
2. 先以 2,000 interval 生成阶段 A 数据，并运行 seed 1/2、每变体最多 25 epoch；只有
   三个检测指标的方向正确时才生成/使用完整数据。
3. 阶段 B 只用完整 train/validation 的 seed 1/2/6 选择一次配置；写入不可变
   `config_lock.json`（包含数据 manifest hash、模型参数、代码 revision 和三个 seed 的验证指标）。
4. 阶段 C 读取 `config_lock.json`，补 seed 17/42，并只进行一次 test 评估；失败的
   单调性必须在最终表中保留，不能以测试指标改参。
5. 完成检测配置冻结后，按 2×50 和 5×100 依次运行 QoS；在线学习只比较 v4
   off/on，且使用固定 12-expert pool + active mask。

## 供下一轮复核的最小验收文件

新的正式实现至少应产生下列文件，再宣布“实验完成”：

```text
artifacts/ftmoe_ablation/
  dataset_manifest.json
  screening_results.csv
  validation_results.csv
  config_lock.json
  test_per_seed.csv
  test_summary.json
  qos_smoke_per_seed.csv
  qos_final_per_seed.csv
  qos_summary.json
```

其中 `test_per_seed.csv` 必须包含 variant、seed、F1、HR@100、NDCG@100、best validation
epoch、checkpoint hash；`test_summary.json` 必须包含均值、标准差和每个相邻变体的配对
置信区间/方向一致种子数。
